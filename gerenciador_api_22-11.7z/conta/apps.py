from django.apps import AppConfig


class ContaConfig(AppConfig):
    name = 'conta'
