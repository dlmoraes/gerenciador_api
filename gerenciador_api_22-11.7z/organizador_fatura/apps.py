from django.apps import AppConfig


class OrganizadorFaturaConfig(AppConfig):
    name = 'organizador_fatura'
