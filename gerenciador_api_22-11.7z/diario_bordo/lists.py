# coding = utf-8

SITUACOES_CHOICES = (
    ('AT', 'Ativo'),
    ('CO', 'Concluído'),
)