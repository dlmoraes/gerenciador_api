from django.apps import AppConfig


class DiarioBordoConfig(AppConfig):
    name = 'diario_bordo'
