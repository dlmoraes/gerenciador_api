from django.apps import AppConfig


class FichasnegociacaoConfig(AppConfig):
    name = 'fichasnegociacao'
