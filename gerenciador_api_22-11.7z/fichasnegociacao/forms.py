#coding=utf8

from django import forms

class BuscaForm(forms.Form):

    alvos = forms.CharField(widget=forms.Textarea)
    tipo = forms.CharField(max_length=1)
