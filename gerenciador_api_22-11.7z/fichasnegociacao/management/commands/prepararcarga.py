from django.core.management.base import BaseCommand, CommandError
from django.db import connection
from ...models import Ficha


class Command(BaseCommand):

    def handle(self, *args, **options):
        self.stdout.write('Preparando tabela de fichas...')
        Ficha.objects.all().delete()
        self.reiniciarSequenciaPK()


    def reiniciarSequenciaPK(self):
        with connection.cursor() as cursor:
            self.stdout.write('Limpando os espações tabela de fichas...')
            cursor.execute("VACUUM")
            self.stdout.write('Reiniciando a sequencia da tabela de fichas...')
            cursor.execute("update sqlite_sequence set seq=0 where name='fichasnegociacao_ficha'")
            self.stdout.write(self.style.SUCCESS('Tabela de fichas pronta para carga!'))